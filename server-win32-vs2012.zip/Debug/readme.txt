0.make sure you have vs2012 runtime.
1.config your ip prot in "server.xml"
2.run server.exe